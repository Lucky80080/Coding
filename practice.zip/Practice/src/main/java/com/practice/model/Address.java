package com.practice.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class Address {
	@Id
	private Integer customer_id;
	private String address;
	private String state;
	private String city;
	private String pincode;
	
	
}

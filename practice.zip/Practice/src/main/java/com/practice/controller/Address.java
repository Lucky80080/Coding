package com.practice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.practice.dao.AddressDao;

@Controller
public class Address {
	@Autowired
	AddressDao addressDao;
	@GetMapping("/saveAddress")
	public String  saveAddress(Address address) {
		addressDao.save(address);
		return "home.jsp";
	}
}

package com.practice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.practice.dao.CustomerDao;
import com.practice.model.Customer;

@Controller
public class CustomerController {
	@Autowired
	CustomerDao customerDao;

	@RequestMapping("/")
	public String home() {
		return "home.jsp";
	}

	@GetMapping("/saveCustomer")
	public String  saveCustomer(Customer customer) {
		customerDao.save(customer);
		return "address.jsp";
	}
}

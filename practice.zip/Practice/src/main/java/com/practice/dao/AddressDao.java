package com.practice.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.practice.model.Address;

public interface AddressDao extends JpaRepository<Address, Integer> {

	

}
